-- ==========================================================
-- Gangchill Database Schema (MySQL / MariaDB)
-- Character Set: utf8mb4, Collation: utf8mb4_unicode_ci
-- ==========================================================

-- 1. Administrators Table
CREATE TABLE IF NOT EXISTS `admins` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('superadmin', 'admin') NOT NULL DEFAULT 'admin',
    `designation` VARCHAR(150) NULL DEFAULT 'প্রশাসনিক নিয়ন্ত্রক',
    `avatar` TEXT NULL,
    `phone` VARCHAR(50) NULL,
    `last_login` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Admin Authentication Sessions Table
CREATE TABLE IF NOT EXISTS `admin_sessions` (
    `token` VARCHAR(128) NOT NULL PRIMARY KEY,
    `admin_id` VARCHAR(64) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_admin_sessions_token` (`token`),
    INDEX `idx_admin_sessions_admin` (`admin_id`),
    CONSTRAINT `fk_session_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Fish Inventory / Stocks Table
CREATE TABLE IF NOT EXISTS `stocks` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `slug` VARCHAR(200) NOT NULL UNIQUE,
    `product_name` VARCHAR(200) NOT NULL,
    `bangla_name` VARCHAR(200) NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `status` ENUM('live', 'upcoming', 'sold') NOT NULL DEFAULT 'live',
    `quantity` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'কেজি (KG)',
    `location` VARCHAR(200) NOT NULL,
    `district` VARCHAR(100) NOT NULL,
    `division` VARCHAR(100) NOT NULL,
    `availability_date` VARCHAR(50) NULL,
    `grade` VARCHAR(100) NULL,
    `harvest_date` VARCHAR(50) NULL,
    `packaging` VARCHAR(150) NULL,
    `minimum_order` DECIMAL(12, 2) NULL,
    `price` DECIMAL(12, 2) NULL,
    `price_type` ENUM('fixed', 'negotiable', 'contact') NOT NULL DEFAULT 'fixed',
    `description` LONGTEXT NULL,
    `images` LONGTEXT NULL,
    `specifications` LONGTEXT NULL,
    `origin_details` LONGTEXT NULL,
    `logistics` LONGTEXT NULL,
    `featured` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_stocks_status` (`status`),
    INDEX `idx_stocks_category` (`category`),
    INDEX `idx_stocks_district` (`district`),
    INDEX `idx_stocks_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Fisheries Investment Opportunities Table
CREATE TABLE IF NOT EXISTS `investments` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `slug` VARCHAR(200) NOT NULL UNIQUE,
    `stock_id` VARCHAR(64) NULL,
    `title` VARCHAR(250) NOT NULL,
    `product_name` VARCHAR(200) NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `location` VARCHAR(200) NOT NULL,
    `required_capital` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `raised_capital` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `minimum_investment` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `profit_percentage` DECIMAL(6, 2) NOT NULL DEFAULT 0.00,
    `duration_days` INT NOT NULL DEFAULT 30,
    `start_date` VARCHAR(50) NULL,
    `settlement_date` VARCHAR(50) NULL,
    `status` ENUM('open', 'funded', 'closed') NOT NULL DEFAULT 'open',
    `description` LONGTEXT NULL,
    `procurement_plan` LONGTEXT NULL,
    `timeline` LONGTEXT NULL,
    `risks` LONGTEXT NULL,
    `security_and_compliance` LONGTEXT NULL,
    `images` LONGTEXT NULL,
    `investor_count` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_investments_status` (`status`),
    INDEX `idx_investments_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Blog / Knowledgebase Articles Table
CREATE TABLE IF NOT EXISTS `blog_posts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `slug` VARCHAR(200) NOT NULL UNIQUE,
    `title` VARCHAR(300) NOT NULL,
    `excerpt` TEXT NULL,
    `content` LONGTEXT NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `featured_image` TEXT NULL,
    `image_alt` VARCHAR(255) NULL,
    `author` VARCHAR(150) NOT NULL DEFAULT 'Gangchill Editorial Team',
    `published_at` VARCHAR(50) NOT NULL,
    `updated_at_date` VARCHAR(50) NULL,
    `reading_time` VARCHAR(50) NOT NULL DEFAULT '৫ মিনিট পড়া',
    `seo_title` VARCHAR(255) NULL,
    `seo_description` TEXT NULL,
    `keywords` LONGTEXT NULL,
    `featured` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_blog_category` (`category`),
    INDEX `idx_blog_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Corporate Buyer Orders Table
CREATE TABLE IF NOT EXISTS `buyer_orders` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `company_name` VARCHAR(200) NOT NULL,
    `contact_person` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `email` VARCHAR(150) NULL,
    `stock_id` VARCHAR(64) NULL,
    `product_name` VARCHAR(200) NOT NULL,
    `quantity` DECIMAL(12, 2) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'কেজি (KG)',
    `required_date` VARCHAR(50) NULL,
    `delivery_location` VARCHAR(255) NOT NULL,
    `specification` TEXT NULL,
    `notes` TEXT NULL,
    `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
    `order_status` ENUM('pending', 'under_review', 'quoted', 'confirmed', 'processing', 'dispatched', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
    `quoted_price_per_unit` DECIMAL(12, 2) NULL,
    `total_estimated_value` DECIMAL(15, 2) NULL,
    `assigned_staff` VARCHAR(150) NULL,
    `status_history` LONGTEXT NULL,
    `internal_notes` LONGTEXT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_orders_status` (`order_status`),
    INDEX `idx_orders_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Seller Lots / Fisherman Harvest Submissions Table
CREATE TABLE IF NOT EXISTS `seller_lots` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `farmer_name` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `district` VARCHAR(100) NOT NULL,
    `product_name` VARCHAR(200) NOT NULL,
    `stock_type` ENUM('current', 'upcoming') NOT NULL DEFAULT 'current',
    `quantity` DECIMAL(12, 2) NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT 'কেজি (KG)',
    `location` VARCHAR(200) NOT NULL,
    `availability_date` VARCHAR(50) NULL,
    `expected_price` DECIMAL(12, 2) NULL,
    `description` TEXT NULL,
    `images` LONGTEXT NULL,
    `status` VARCHAR(50) NOT NULL DEFAULT 'submitted',
    `verification_status` ENUM('pending', 'verified', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    `field_inspector_name` VARCHAR(150) NULL,
    `inspection_notes` TEXT NULL,
    `approved_wholesale_price` DECIMAL(12, 2) NULL,
    `converted_stock_id` VARCHAR(64) NULL,
    `stock_deleted_at` DATETIME NULL,
    `stock_deleted_name` VARCHAR(255) NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_lots_status` (`verification_status`),
    INDEX `idx_lots_deleted` (`stock_deleted_at`),
    INDEX `idx_lots_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Investor Interest & Pledges Table
CREATE TABLE IF NOT EXISTS `investor_interests` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `opportunity_id` VARCHAR(64) NOT NULL,
    `opportunity_title` VARCHAR(250) NOT NULL,
    `investor_name` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `email` VARCHAR(150) NULL,
    `interested_amount` DECIMAL(15, 2) NOT NULL,
    `expected_profit` DECIMAL(15, 2) NULL,
    `notes` TEXT NULL,
    `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_inv_interests_opp` (`opportunity_id`),
    INDEX `idx_inv_interests_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. General Contact Messages Table
CREATE TABLE IF NOT EXISTS `contact_messages` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Corporate Customers Directory Table
CREATE TABLE IF NOT EXISTS `customers` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `company_name` VARCHAR(200) NOT NULL,
    `business_type` VARCHAR(100) NOT NULL,
    `contact_person` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `email` VARCHAR(150) NULL,
    `delivery_location` VARCHAR(255) NOT NULL,
    `tier` ENUM('VIP', 'Regular', 'New') NOT NULL DEFAULT 'New',
    `total_orders_count` INT NOT NULL DEFAULT 0,
    `total_volume_kg` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `total_order_value` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `last_order_date` VARCHAR(50) NULL,
    `preferred_fish` LONGTEXT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_customers_tier` (`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Fishermen / Suppliers Directory Table
CREATE TABLE IF NOT EXISTS `suppliers` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `farmer_name` VARCHAR(150) NOT NULL,
    `type` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `district` VARCHAR(100) NOT NULL,
    `location` VARCHAR(200) NOT NULL,
    `verification_badge` ENUM('verified', 'provisional', 'new') NOT NULL DEFAULT 'new',
    `total_lots_count` INT NOT NULL DEFAULT 0,
    `total_volume_kg` DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    `quality_rating` DECIMAL(3, 1) NOT NULL DEFAULT 4.5,
    `primary_species` LONGTEXT NULL,
    `joined_date` VARCHAR(50) NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_suppliers_district` (`district`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Administrative Activity Audit Log Table
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `action` VARCHAR(255) NOT NULL,
    `target_type` VARCHAR(50) NOT NULL,
    `target_title` VARCHAR(255) NOT NULL,
    `actor` VARCHAR(150) NOT NULL,
    `details` TEXT NULL,
    `timestamp` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_activity_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. System & Platform Settings Table (Single-row configuration)
CREATE TABLE IF NOT EXISTS `platform_settings` (
    `id` INT NOT NULL PRIMARY KEY DEFAULT 1,
    `settings_json` LONGTEXT NOT NULL,
    `updated_by` VARCHAR(150) NULL,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Media Uploads Registry Table
CREATE TABLE IF NOT EXISTS `media_uploads` (
    `id` VARCHAR(64) NOT NULL PRIMARY KEY,
    `file_name` VARCHAR(255) NOT NULL,
    `original_name` VARCHAR(255) NOT NULL,
    `mime_type` VARCHAR(100) NOT NULL,
    `file_size` INT NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `public_url` VARCHAR(255) NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_media_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. Login Security & Brute-Force Rate Limiting Table
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ip_address` VARCHAR(64) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `attempted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_attempts_ip` (`ip_address`, `attempted_at`),
    INDEX `idx_attempts_email` (`email`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================================
-- DEFAULT SUPERADMIN ACCOUNT (Password: admin123)
-- ==========================================================
INSERT INTO `admins` (`id`, `name`, `email`, `password_hash`, `role`, `designation`, `avatar`, `phone`)
VALUES (
    'adm-001',
    'MD Admin',
    'admin@gangchill.com',
    '$2y$10$pSsiJEDFzQ8P1ISMOKKcs.yVmZsf4VWm3OX4AlJgSh/U1krrH2eNa',
    'superadmin',
    'ম্যানেজিং ডিরেক্টর ও অ্যাডমিন',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    '01712-345678'
)
ON DUPLICATE KEY UPDATE `email` = VALUES(`email`);

-- ==========================================================
-- GANGCHILL INITIAL SEED DATA (PRODUCTS, BLOG, INVESTMENTS)
-- ==========================================================

-- 1. Platform Settings
INSERT INTO `platform_settings` (`id`, `settings_json`, `updated_by`) VALUES (1, '{"platformName":"Gangchill B2B Hub","tagline":"জাতীয় সামুদ্রিক ও নদীর মাছের পাইকারি সরবরাহ নেটওয়ার্ক","supportEmail":"supply@gangchill.com","emergencyHotline":"+880 1712-345678","businessHours":"শনিবার - বৃহস্পতিবার: সকাল ৮টা - রাত ১০টা","headOfficeAddress":"হাউস ১২, রোড ৯, ব্লক-সি, গুলশান-১, ঢাকা ১২১২, বাংলাদেশ","hubLocations":"চাঁদপুর বড়স্টেশন, কক্সবাজার ফিশারি ঘাট, খুলনা রূপসা, নাটোর চলনবিল, ভৈরব মেঘনা ঘাট","defaultMoqKg":50,"coldChainEnabled":true,"allowPublicSellerSubmissions":true,"allowPublicInvestorInterest":true,"maintenanceMode":false,"notifyOnNewOrder":true,"notifyOnNewLot":true,"notifyOnNewInvestmentInterest":true}', 'MD Admin') ON DUPLICATE KEY UPDATE `settings_json` = VALUES(`settings_json`);

-- 2. Fish Inventory & Stocks
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-1', 'chandpur-padma-hilsa-live', 'Chandpur Padma River Hilsa', 'চাঁদপুরের পদ্মার রূপালী ইলিশ', 'ইলিশ', 'live', 1.2, 'টন (MT)',
  'বড়স্টেশন ঘাট, চাঁদপুর', 'চাঁদপুর', 'চট্টগ্রাম', 'গ্রেড A (১ কেজি - ১.২ কেজি সাইজ)', 'আজ ভোরের আহরণ', 'ইনসুলেটেড আইস বক্স (২০ কেজি)', 100,
  1650, 'fixed', 'চাঁদপুরের বড়স্টেশন মাছঘাট থেকে সরাসরি সংগৃহীত পদ্মার খাঁটি রূপালী ইলিশ। চকচকে আঁশ, উজ্জ্বল চোখ ও অক্ষত পেট। কর্পোরেট ক্যাটারিং, এক্সক্লুসিভ সুপারমার্কেট ও প্রিমিয়াম হোটেলের জন্য শতভাগ উপযুক্ত। কোল্ড-চেইন ট্রাকে তাজা ডেলিভারি।', '["https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1534943441045-1089b75eb353?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"মাছের ধরন","value":"পদ্মা ও মেঘনা নদীর টাটকা ইলিশ"},{"label":"আকার ও ওজন","value":"১০০০ গ্রাম - ১২০০ গ্রাম প্রতি পিস"},{"label":"তাজাত্ব সূচক","value":"১০০% টাটকা (ফ্রিজিং ছাড়া ফ্রেশ বরফ দেওয়া)"},{"label":"সংরক্ষণ পদ্ধতি","value":"ফুড-গ্রেড প্লাস্টিক ইনসুলেটেড আইস চেম্বার"},{"label":"প্যাকেজিং","value":"২০ কেজি এয়ারটাইট থার্মোকল / ক্রাফট বক্স"},{"label":"ন্যূনতম ক্রয়সীমা","value":"১০০ কেজি"}]', '{"unionOrVillage":"বড়স্টেশন ও মোহনা ঘাট","farmerGroup":"মেঘনা মোহনা জেলে সমবায় ক্লাস্টার","farmingMethod":"নদীর প্রাকৃতিক মাছ ধরা (জাল আহরণ)"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"আজ বিকেলে ঢাকায় সরাসরি কোল্ডচেইন ডেলিভারি"}', 1
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-2', 'khulna-black-tiger-bagda-shrimp', 'Khulna Black Tiger Bagda Shrimp', 'খুলনা ও সাতক্ষীরার বাগদা চিংড়ি', 'চিংড়ি', 'live', 850, 'কেজি (KG)',
  'পাইকগাছা, খুলনা', 'খুলনা', 'খুলনা', 'এক্সপোর্ট গ্রেড (১৬/২০ কাউন্ট)', 'আজকের সংগ্রহ', '১০ ও ২০ কেজি আইস ক্রাফট কার্টন', 50,
  920, 'fixed', 'খুলনা ও সাতক্ষীরার লবণাক্ত পানির প্রাকৃতিক ঘের থেকে ভোরে আহরিত এক্সপোর্ট কোয়ালিটি বাগদা চিংড়ি। হেড-অন শেল-অন (HOSO), শক্ত খোলস এবং চমৎকার চকচকে রঙ। সিফুড প্রসেসিং কারখানা ও চাইনিজ রেস্তোরাঁ চেইনের জন্য আদর্শ।', '["https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1559742811-822873691df8?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"প্রজাতি","value":"ব্ল্যাক টাইগার (Penaeus monodon)"},{"label":"গ্রেড ও কাউন্ট","value":"১৬-২০ পিস প্রতি কেজি"},{"label":"প্রসেসিং অবস্থা","value":"ফ্রেশ হেড-অন শেল-অন (HOSO)"},{"label":"অ্যান্টিবায়োটিক স্ট্যাটাস","value":"১০০% পরীক্ষিত ও অর্গানিক ঘের"}]', '{"unionOrVillage":"কপোতাক্ষ অববাহিকা ক্লাস্টার","farmerGroup":"পাইকগাছা চিংড়ি চাষী ফোরাম","farmingMethod":"ঐতিহ্যবাহী লবণাক্ত পানির প্রাকৃতিক ঘের"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"২৪ ঘণ্টার মধ্যে সারা দেশে সরবরাহ"}', 1
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-3', 'mymensingh-live-deshi-rui', 'Mymensingh Fresh Deshi Rui', 'ময়মনসিংহের তাজা দেশি রুই', 'দেশি মাছ', 'live', 2.5, 'টন (MT)',
  'ত্রিশাল ও তারাকান্দা, ময়মনসিংহ', 'ময়মনসিংহ', 'ময়মনসিংহ', 'গ্রেড A (২.৫ কেজি - ৩.৫ কেজি সাইজ)', 'আজ সকালে জলাশয় থেকে ধরা', 'অক্সিজেন ড্রাম ও আইস বক্স', 200,
  360, 'fixed', 'ব্রহ্মপুত্র অববাহিকার গভীর মিষ্টি পানির পুকুর থেকে সংগৃহীত বড় সাইজের লালচে রুই মাছ। ফিড-গন্ধহীন, সুস্বাদু ও তেলতেলে পেট। রাজধানীর পাইকারি আড়ত, ক্যাটারার ও সুপারশপে জীবন্ত বা ড্রাম-বরফে সরবরাহের সুবিধা।', '["https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"প্রজাতি","value":"দেশি রুই (Labeo rohita)"},{"label":"ওজন সাইজ","value":"২.৫ কেজি থেকে ৩.৫ কেজি+"},{"label":"ডেলিভারি ধরন","value":"লাইভ অক্সিজেন ওয়াটার ভ্যান অথবা বরফ লট"},{"label":"প্যাকেজিং","value":"৫০ কেজি ড্রাম / ক্রাফট বক্স"}]', '{"unionOrVillage":"ত্রিশাল ফিশারি ক্লাস্টার","farmerGroup":"ময়মনসিংহ একোয়া কালচার সমবায়","farmingMethod":"প্রাকৃতিক প্রবাহমান মিষ্টি পানির খামার"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"৮ ঘণ্টার মধ্যে ঢাকায় সরাসরি ডেলিভারি"}', 1
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-4', 'coxsbazar-loitta-rupchanda-dry-fish', 'Coxs Bazar Organic Dry Fish (Shutki)', 'কক্সবাজারের অর্গানিক লইট্যা ও রূপচাঁদা শুঁটকি', 'শুঁটকি', 'live', 1.5, 'টন (MT)',
  'নাজিরারটেক, কক্সবাজার', 'কক্সবাজার', 'চট্টগ্রাম', 'এক্সপোর্ট প্রিমিয়াম (কীটনাশকমুক্ত)', 'সেপ্টেম্বর ২০২৬ ব্যাচ', '২৫ কেজি পলি-লাইনড চটের বস্তা', 50,
  850, 'fixed', 'কক্সবাজারের ঐতিহ্যবাহী নাজিরারটেক শুঁটকি পল্লীতে সম্পূর্ণ বিষমুক্ত ও প্রাকৃতিক সমুদ্রের বাতাসে শুকানো লইট্যা ও রূপচাঁদা শুঁটকি। কোনো কীটনাশক বা রাসায়নিক দেওয়া হয়নি। দীর্ঘস্থায়ী ও নির্ভেজাল স্বাদ।', '["/nazirartek-shutki.jpg"]', '[{"label":"মাছের ধরন","value":"লইট্যা, রূপচাঁদা ও ছুরি শুঁটকি"},{"label":"শুকানোর পদ্ধতি","value":"১০০% রোদে ও সমুদ্রের বাতাসে ড্রাইং (অর্গানিক)"},{"label":"আর্দ্রতা","value":"সর্বোচ্চ ১২%"},{"label":"রাসায়নিক ও লবণ","value":"সম্পূর্ণ কীটনাশকমুক্ত, পরিমিত লবণ"}]', '{"unionOrVillage":"নাজিরারটেক শুঁটকি পল্লী","farmerGroup":"কক্সবাজার অর্গানিক শুঁটকি উৎপাদক দল","farmingMethod":"ঐতিহ্যবাহী মাচা পদ্ধতি ও সোলার ড্রাই"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"২৪-৪৮ ঘণ্টার মধ্যে সারা দেশে সরবরাহ"}', 1
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-5', 'barisal-meghna-hilsa-upcoming', 'Barisal River Hilsa Upcoming Batch', 'বরিশাল ও ভোলার নদীর তাজা ইলিশ (আসন্ন লট)', 'ইলিশ', 'upcoming', 2, 'টন (MT)',
  'পোর্ট রোড ঘাট, বরিশাল', 'বরিশাল', 'বরিশাল', 'সুপার গ্রেড (৮০০ গ্রাম - ১ কেজি)', '১২ সেপ্টেম্বর ২০২৬', 'ইনসুলেটেড আইস বক্স', 100,
  1350, 'contact', 'তেঁতুলিয়া ও মেঘনার সংযোগস্থল থেকে আসন্ন অমাবস্যার জোতে আহরিত হতে যাওয়া প্রিমিয়াম সাইজের ইলিশের লট। বড় পাইকার ও করপোরেট ক্রয়ের জন্য অগ্রিম বুকিং নেওয়া হচ্ছে।', '["https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"উৎস নদী","value":"মেঘনা ও তেঁতুলিয়া মোহনা"},{"label":"প্রত্যাশিত ওজন","value":"৮০০ গ্রাম - ১০০০ গ্রাম"},{"label":"সংগ্রহ উইন্ডো","value":"১২-১৫ সেপ্টেম্বর ২০২৬"}]', '{"unionOrVillage":"পোর্ট রোড ও ভোলা চরফ্যাশন ক্লাস্টার","farmerGroup":"দক্ষিণাঞ্চল মৎস্যজীবী সমবায়","farmingMethod":"নদীর ট্রলার আহরণ"}', '{"warehouseReady":false,"transportAssistance":true,"estimatedDeliveryDays":"আহরণের দিনে সরাসরি ভোরে ডেলিভারি"}', 0
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-6', 'jessore-freshwater-golda-prawn', 'Jessore Freshwater Golda Prawn', 'যশোরের মিঠাপানির গলদা চিংড়ি (আসন্ন লট)', 'চিংড়ি', 'upcoming', 1.2, 'টন (MT)',
  'কেশবপুর ও অভয়নগর, যশোর', 'যশোর', 'খুলনা', 'গ্রেড A (৮-১২ কাউন্ট)', '১৮ সেপ্টেম্বর ২০২৬', 'আইস চেম্বার বক্স', 40,
  1100, 'negotiable', 'যশোরের মিষ্টি পানির ঐতিহ্যবাহী ঘের থেকে আসন্ন গলদা চিংড়ি সংগ্রহের লট। বড় নখযুক্ত, মোটা শরীর ও সুস্বাদু স্বাদের জন্য বিখ্যাত।', '["https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"প্রজাতি","value":"মিঠাপানির গলদা (Macrobrachium rosenbergii)"},{"label":"কাউন্ট","value":"৮-১২ পিস প্রতি কেজি (জায়ান্ট সাইজ)"},{"label":"সংগ্রহ এলাকা","value":"যশোর ঘের বেল্ট"}]', '{"unionOrVillage":"কেশবপুর একোয়া জোন","farmerGroup":"যশোর গলদা চাষী সমবায়","farmingMethod":"মিষ্টি পানির পরিবেশবান্ধব মিশ্র ঘের"}', '{"warehouseReady":false,"transportAssistance":true,"estimatedDeliveryDays":"১৮ সেপ্টেম্বর থেকে সরাসরি ডেলিভারি"}', 0
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-7', 'sylhet-haor-shing-koi-live', 'Sylhet Haor Deshi Shing & Koi', 'সিলেট ও সুনামগঞ্জ হাওরের জীবন্ত দেশি শিং ও কৈ', 'দেশি মাছ', 'live', 600, 'কেজি (KG)',
  'তাহিরপুর হাওর, সুনামগঞ্জ', 'সুনামগঞ্জ', 'সিলেট', 'খাঁটি হাওরের ন্যাচারাল', 'আজ সকালে আহরিত', 'লাইভ ওয়াটার ড্রাম', 50,
  680, 'fixed', 'টাঙ্গুয়ার হাওরের প্রাকৃতিক জলাশয় থেকে স্থানীয় জেলেদের দ্বারা আহরিত খাঁটি দেশি জ্যান্ত শিং ও কৈ মাছ। ১০০% কৃত্রিম খাদ্যমুক্ত ও পুষ্টিগুণে সমৃদ্ধ।', '["https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=1200&q=80"]', '[{"label":"মাছের জাত","value":"দেশি শিং ও দেশি কৈ"},{"label":"উৎস","value":"টাঙ্গুয়ার হাওরের মুক্ত জলাশয়"},{"label":"অবস্থা","value":"জীবন্ত (Live Delivery)"}]', '{"unionOrVillage":"তাহিরপুর হাওর এলাকা","farmerGroup":"হাওর মৎস্যজীবী সমিতি","farmingMethod":"মুক্ত জলাশয়ের প্রাকৃতিক মাছ"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"অক্সিজেন ভ্যানে ১২ ঘণ্টায় ঢাকা ও সিলেট সরবরাহ"}', 0
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
INSERT INTO `stocks` (`id`, `slug`, `product_name`, `bangla_name`, `category`, `status`, `quantity`, `unit`, `location`, `district`, `division`, `grade`, `harvest_date`, `packaging`, `minimum_order`, `price`, `price_type`, `description`, `images`, `specifications`, `origin_details`, `logistics`, `featured`) VALUES (
  'fish-8', 'natore-chalanbeel-pabda', 'Chalan Beel Fresh Pabda Fish', 'নাটোর চলনবিলের তাজা পাবদা মাছ', 'দেশি মাছ', 'live', 500, 'কেজি (KG)',
  'সিংড়া, নাটোর', 'নাটোর', 'রাজশাহী', 'গ্রেড A (২০-২৫ পিস/কেজি)', 'আজ ভোরের আহরণ', 'আইস ক্রাফট বক্স', 30,
  480, 'fixed', 'চলনবিলের সুমিষ্ট পানির চকচকে তাজা পাবদা মাছ। কাঁটাহীন নরম মাংস ও তুলনাহীন স্বাদ। সুপারমার্কেট ও প্রিমিয়াম হোটেলের সরাসরি সংগ্রহের জন্য প্রস্তুত।', '["/chalanbeel-pabda.jpg"]', '[{"label":"জাত","value":"দেশি পাবদা (Ompok pabda)"},{"label":"সাইজ","value":"২০-২৫ পিস প্রতি কেজি"},{"label":"সংরক্ষণ","value":"ফ্রিজিং ছাড়া বরফে টাটকা সংরক্ষিত"}]', '{"unionOrVillage":"সিংড়া চলনবিল জোন","farmerGroup":"চলনবিল দেশি মৎস্য উৎপাদনকারী দল","farmingMethod":"বিল সংলগ্ন প্রাকৃতিক খামার"}', '{"warehouseReady":true,"transportAssistance":true,"estimatedDeliveryDays":"আজ বিকেলের মধ্যে ঢাকা পৌঁছাবে"}', 0
) ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);

-- 3. Fisheries Investments Projects
INSERT INTO `investments` (`id`, `slug`, `stock_id`, `title`, `product_name`, `category`, `location`, `required_capital`, `raised_capital`, `minimum_investment`, `profit_percentage`, `duration_days`, `start_date`, `settlement_date`, `status`, `description`, `procurement_plan`, `timeline`, `risks`, `security_and_compliance`, `images`, `investor_count`) VALUES (
  'inv-fish-1', 'chandpur-hilsa-coldchain-procurement', 'fish-1', 'চাঁদপুর বড়স্টেশন ঘাট থেকে ২ টন ইলিশ সংগ্রহ', 'পদ্মা ও মেঘনার রূপালী ইলিশ', 'ইলিশ', 'বড়স্টেশন ঘাট, চাঁদপুর',
  3000000, 2150000, 50000, 8.5, 45, '১ সেপ্টেম্বর ২০২৬', '১৫ অক্টোবর ২০২৬', 'open', 'চাঁদপুরের বড়স্টেশন মাছঘাট থেকে সরাসরি তালিকাভুক্ত জেলে ট্রলার থেকে ২ টন প্রিমিয়াম পদ্মা-মেঘনা ইলিশ সংগ্রহ, আইসিং ও দ্রুত কোল্ড-চেইন ট্রান্সপোর্টের মাধ্যমে ঢাকার শীর্ষ ৪টি সুপারমার্কেট চেইনে সরবরাহের একটি লাভজনক প্রকল্প।',
  '{"targetQuantity":2,"unit":"টন (MT)","sourceRegion":"বড়স্টেশন ঘাট ও মেঘনা মোহনা, চাঁদপুর","targetBuyers":"শীর্ষস্থানীয় সুপারশপ চেইন, কর্পোরেট ক্যাটারার ও প্রিমিয়াম পাইকার","purchaseWindow":"১ সেপ্টেম্বর - ৮ সেপ্টেম্বর ২০২৬","salesWindow":"১০ সেপ্টেম্বর - ৫ অক্টোবর ২০২৬"}', '[{"stage":1,"title":"বিনিয়োগ তহবিল সংগ্রহ","duration":"৭ দিন","description":"অনলাইন পোর্টালের মাধ্যমে ৳ ৩০,০০,০০০ মূলধন সংগ্রহ সম্পন্ন করা।","status":"active"},{"stage":2,"title":"চাঁদপুর ঘাট থেকে সরাসরি ট্রলার আহরণ ক্রয়","duration":"১০ দিন","description":"জেলে নৌকা ও আড়ত থেকে তাজা ইলিশ ওজন, কোয়ালিটি গ্রেডিং ও থার্মোকল বক্সে আইসিং।","status":"pending"},{"stage":3,"title":"কোল্ডচেইন ডেলিভারি ও চালান হস্তান্তর","duration":"২০ দিন","description":"তাপমাত্রা নিয়ন্ত্রিত রেফ্রিজারেটেড ভ্যানে সুপারশপ ওয়্যারহাউসে ডেলিভারি ও ইনভয়েস সমন্বয়।","status":"pending"},{"stage":4,"title":"হিসাব নিষ্পত্তি ও ৮.৫% লভ্যাংশ ফেরত","duration":"৮ দিন","description":"বিক্রয়লব্ধ অর্থ ব্যাংক এস্ক্রো একাউন্ট থেকে বিনিয়োগকারীদের অ্যাকাউন্টে মুনাফাসহ ফেরত।","status":"pending"}]', '["মাছের সতেজতা বজায় রাখতে Gangchill নিজস্ব ইনসুলেটেড আইস চেইন ও ডিজিটাল থার্মোমিটার ব্যবহার করে।","আহরিত মাছের পূর্বেই করপোরেট কার্যাদেশ (Purchase Order) নিশ্চিত থাকায় বিক্রয় ঝুঁকি নেই।"]', '["প্রতিটি বিনিয়োগের বিপরীতে আইনি ডিজিটাল চুক্তিপত্র ও মানি রিসিপ্ট প্রদান করা হয়।","প্রকল্পের প্রতিটি চালানের ওজন ও ডেলিভারি স্ট্যাটাস নিয়মিত ড্যাশবোর্ডে আপডেট করা হয়।"]', '["https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=1200&q=80","https://images.unsplash.com/photo-1534943441045-1089b75eb353?auto=format&fit=crop&w=1200&q=80"]', 26
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `investments` (`id`, `slug`, `stock_id`, `title`, `product_name`, `category`, `location`, `required_capital`, `raised_capital`, `minimum_investment`, `profit_percentage`, `duration_days`, `start_date`, `settlement_date`, `status`, `description`, `procurement_plan`, `timeline`, `risks`, `security_and_compliance`, `images`, `investor_count`) VALUES (
  'inv-fish-2', 'satkhira-khulna-bagda-export-supply', 'fish-2', 'সাতক্ষীরা ও খুলনা থেকে ৩ টন বাগদা চিংড়ি সংগ্রহ', 'ব্ল্যাক টাইগার বাগদা চিংড়ি', 'চিংড়ি', 'শ্যামনগর ও পাইকগাছা, খুলনা',
  4000000, 3200000, 100000, 9, 60, '৫ সেপ্টেম্বর ২০২৬', '৫ নভেম্বর ২০২৬', 'open', 'খুলনা ও সাতক্ষীরার লবণাক্ত ঘের থেকে সরাসরি ৩ টন এক্সপোর্ট গ্রেডের বাগদা চিংড়ি সংগ্রহ করে সিফুড প্রসেসিং কারখানায় সরবরাহের উচ্চ-মূল্যবান প্রকল্প।',
  '{"targetQuantity":3,"unit":"টন (MT)","sourceRegion":"শ্যামনগর, আশাশুনি ও পাইকগাছা ঘের বেল্ট","targetBuyers":"অনুমোদিত সিফুড এক্সপোর্ট প্রসেসিং প্ল্যান্ট ও ফাইভ-স্টার হোটেল চেইন","purchaseWindow":"৫ সেপ্টেম্বর - ১৫ সেপ্টেম্বর ২০২৬","salesWindow":"২০ সেপ্টেম্বর - ২৫ অক্টোবর ২০২৬"}', '[{"stage":1,"title":"তহবিল আহ্বান","duration":"৮ দিন","description":"অনলাইনে বিনিয়োগ সংগ্রহ চলমান।","status":"active"},{"stage":2,"title":"ঘের থেকে সংগ্রহ ও কাউন্ট গ্রেডিং","duration":"১৫ দিন","description":"ঘের পয়েন্টে ল্যাব টেস্ট, ওজন ও ১৬/২০ কাউন্ট অনুযায়ী গ্রেডিং।","status":"pending"},{"stage":3,"title":"প্রসেসিং প্ল্যান্টে সরবরাহ","duration":"২৫ দিন","description":"কারখানায় চালান হস্তান্তর ও এক্সপোর্ট ক্লিয়ারেন্স সম্পন্ন।","status":"pending"},{"stage":4,"title":"মুনাফাসহ ৯% লভ্যাংশ বণ্টন","duration":"১২ দিন","description":"নির্ধারিত মেয়াদের মধ্যে সরাসরি একাউন্টে অর্থ ফেরত।","status":"pending"}]', '["অ্যান্টিবায়োটিক মুক্ত মাছের জন্য পূর্ব-অনুমোদিত ঘের থেকেই শুধুমাত্র সংগ্রহ করা হয়।"]', '["১০০% ব্যাংকিং চ্যানেলে স্বচ্ছ লেনদেন ও অডিট রিপোর্ট প্রদান।"]', '["https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=1200&q=80"]', 31
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `investments` (`id`, `slug`, `stock_id`, `title`, `product_name`, `category`, `location`, `required_capital`, `raised_capital`, `minimum_investment`, `profit_percentage`, `duration_days`, `start_date`, `settlement_date`, `status`, `description`, `procurement_plan`, `timeline`, `risks`, `security_and_compliance`, `images`, `investor_count`) VALUES (
  'inv-fish-3', 'coxsbazar-organic-shutki-batch', 'fish-4', 'কক্সবাজার নাজিরারটেক থেকে ৫ টন প্রিমিয়াম শুঁটকি সংগ্রহ', 'বিষমুক্ত লইট্যা, রূপচাঁদা ও ছুরি শুঁটকি', 'শুঁটকি', 'নাজিরারটেক, কক্সবাজার',
  2500000, 1950000, 50000, 8.5, 60, '১০ সেপ্টেম্বর ২০২৬', '১০ নভেম্বর ২০২৬', 'open', 'নাজিরারটেকের ঐতিহ্যবাহী শুঁটকি পল্লী থেকে সরাসরি ৫ টন অর্গানিক শুকনা মাছের বাল্ক লট সংগ্রহ করে ঢাকার কাওরান বাজার ও সুপারমার্কেটে পর্যায়ক্রমে সরবরাহের কম-ঝুঁকিপূর্ণ প্রকল্প।',
  '{"targetQuantity":5,"unit":"টন (MT)","sourceRegion":"নাজিরারটেক শুঁটকি জোন, কক্সবাজার","targetBuyers":"পাইকারি শুঁটকি আড়তদার ও সুপারশপ প্যাকেজিং ভেন্ডর","purchaseWindow":"১০ সেপ্টেম্বর - ২০ সেপ্টেম্বর ২০২৬","salesWindow":"১ অক্টোবর - ৩০ অক্টোবর ২০২৬"}', '[{"stage":1,"title":"তহবিল সংগ্রহ","duration":"১০ দিন","description":"প্রকল্প তহবিল সংগ্রহ।","status":"active"},{"stage":2,"title":"শুঁটকি পল্লী থেকে লট ক্রয় ও কোয়ালিটি ড্রায়িং টেস্ট","duration":"১৫ দিন","description":"কীটনাশকমুক্ত ও আর্দ্রতা ১২% নিশ্চিত করে ক্রয়।","status":"pending"},{"stage":3,"title":"ওয়্যারহাউস স্টোরেজ ও চালান ডেলিভারি","duration":"২৫ দিন","description":"ঢাকার পাইকারি ক্রেতাদের নিকট নিয়মিত ডেলিভারি।","status":"pending"},{"stage":4,"title":"সেটেলমেন্ট ও মুনাফা প্রদান","duration":"১০ দিন","description":"৮.৫% প্রফিটসহ বিনিয়োগকারীদের মূলধন ফেরত।","status":"pending"}]', '["শুঁটকি শুষ্ক ও দীর্ঘস্থায়ী হওয়ায় কোনো পচন ঝুঁকি নেই।"]', '["ল্যাব টেস্ট সার্টিফিকেট ও চুক্তিভিত্তিক নিরাপত্তা।"]', '["/nazirartek-shutki.jpg"]', 22
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `investments` (`id`, `slug`, `stock_id`, `title`, `product_name`, `category`, `location`, `required_capital`, `raised_capital`, `minimum_investment`, `profit_percentage`, `duration_days`, `start_date`, `settlement_date`, `status`, `description`, `procurement_plan`, `timeline`, `risks`, `security_and_compliance`, `images`, `investor_count`) VALUES (
  'inv-fish-4', 'mymensingh-live-rui-katla-supply', 'fish-3', 'ময়মনসিংহ ও ত্রিশাল থেকে ৫ টন তাজা দেশি মাছ সংগ্রহ', 'দেশি রুই, কাতলা ও মৃগেল', 'দেশি মাছ', 'ত্রিশাল ও ভালুকা, ময়মনসিংহ',
  1500000, 1500000, 30000, 7.5, 30, '১৫ আগস্ট ২০২৬', '১৫ সেপ্টেম্বর ২০২৬', 'funded', 'ময়মনসিংহের গভীর পুকুর থেকে সংগৃহীত বড় সাইজের রুই-কাতলা মাছ সরাসরি ঢাকার পাইকারি আড়ত ও সুপারশপে সরবরাহের দ্রুততম ৩০ দিনের ঘূর্ণায়মান প্রকল্প। শতভাগ অর্থ সংগৃহীত।',
  '{"targetQuantity":5,"unit":"টন (MT)","sourceRegion":"ত্রিশাল ও ভালুকা, ময়মনসিংহ","targetBuyers":"যাত্রাবাড়ী ও কাওরান বাজার আড়ত এবং সুপারমার্কেট চেইন","purchaseWindow":"১৫ আগস্ট - ২০ আগস্ট ২০২৬","salesWindow":"২৫ আগস্ট - ১০ সেপ্টেম্বর ২০২৬"}', '[{"stage":1,"title":"তহবিল সংগ্রহ সম্পন্ন","duration":"৫ দিন","description":"শতভাগ তহবিল সফলভাবে অর্জিত।","status":"completed"},{"stage":2,"title":"মাঠের খামার থেকে জাল দিয়ে আহরণ","duration":"১০ দিন","description":"মাছ ধরা ও অক্সিজেন ভ্যানে লোডিং সম্পন্ন।","status":"completed"},{"stage":3,"title":"ঢাকায় ডেলিভারি ও বিক্রয় চালান","duration":"১০ দিন","description":"বর্তমানে ঢাকা আড়তে ডেলিভারি চলছে।","status":"active"},{"stage":4,"title":"মূলধন ও মুনাফা ফেরত","duration":"৫ দিন","description":"নির্ধারিত তারিখে অর্থ হস্তান্তর হবে।","status":"pending"}]', '["লাইভ অক্সিজেন ভ্যান ও আইস চেইন ব্যবহারের মাধ্যমে শূন্য অপচয় নিশ্চিত।"]', '["স্বচ্ছ হিসাবনিকাশ ও সরাসরি ব্যাংক একাউন্টে সেটেলমেন্ট।"]', '["https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=1200&q=80"]', 28
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);

-- 4. CMS Blog Posts
INSERT INTO `blog_posts` (`slug`, `title`, `excerpt`, `content`, `category`, `featured_image`, `image_alt`, `author`, `published_at`, `reading_time`, `seo_title`, `seo_description`, `keywords`, `featured`) VALUES (
  'ilish-mousum-2026-chandpur-theke-dhaka-bazar', 'ইলিশ মৌসুম ২০২৬: চাঁদপুর ঘাট থেকে ঢাকার বাজার পর্যন্ত সরবরাহ চেইন', 'পদ্মা ও মেঘনার মোহনায় ইলিশ আহরণের ভরা মৌসুমে ঘাট থেকে পাইকারি ক্রেতা পর্যন্ত মাছ পৌঁছানোর প্রতিটি ধাপ—আহরণ, গ্রেডিং, আইসিং ও কোল্ড-চেইন পরিবহন—বিস্তারিতভাবে জানুন।', '[{"type":"paragraph","text":"প্রতি বছর জুলাই থেকে অক্টোবর—পদ্মা ও মেঘনার মোহনায় ইলিশ আহরণের ভরা মৌসুম। এই সময়ে চাঁদপুরের বড়স্টেশন ঘাট বাংলাদেশের সবচেয়ে ব্যস্ত ইলিশ সরবরাহ কেন্দ্রে পরিণত হয়। কিন্তু ঘাট থেকে একটি ইলিশ ঢাকার সুপারমার্কেট বা রেস্তোরাঁর প্লেটে পৌঁছাতে ঠিক কী কী ধাপ পার হয়?"},{"type":"heading","text":"১. আহরণ ও প্রথমিক বাছাই"},{"type":"paragraph","text":"ভোরের আলো ফোটার আগেই জেলে নৌকাগুলো ঘাটে ভিড়তে শুরু করে। প্রতিটি চালান ঘাটেই আকার, ওজন ও তাজাত্ব অনুযায়ী প্রাথমিকভাবে বাছাই করা হয়। উজ্জ্বল আঁশ, স্বচ্ছ চোখ ও অক্ষত পেট—এই তিনটি সূচক দিয়ে গ্রেড নির্ধারণ করা হয়।"},{"type":"heading","text":"২. গ্রেডিং ও ওজন অনুযায়ী শ্রেণিবিন্যাস"},{"type":"paragraph","text":"সাধারণত ৮০০ গ্রামের নিচের ইলিশ, ১০০০-১২০০ গ্রামের মাঝারি ইলিশ এবং ১২০০ গ্রামের ওপরের প্রিমিয়াম গ্রেড—এই তিন শ্রেণিতে ভাগ করা হয়। কর্পোরেট ক্যাটারার ও প্রিমিয়াম সুপারশপের চাহিদা সাধারণত মাঝারি থেকে বড় গ্রেডের দিকে বেশি থাকে।"},{"type":"heading","text":"৩. আইসিং ও ইনসুলেটেড প্যাকেজিং"},{"type":"paragraph","text":"বাছাই সম্পন্ন হওয়ার সাথে সাথেই ফুড-গ্রেড বরফ দিয়ে ইনসুলেটেড থার্মোকল বাক্সে প্যাক করা হয়। এই ধাপে কোনো রকম রাসায়নিক বা ফরমালিন ব্যবহারের প্রশ্নই আসে না—শুধু বরফ ও সঠিক তাপমাত্রা নিয়ন্ত্রণই যথেষ্ট।"},{"type":"heading","text":"৪. কোল্ড-চেইন পরিবহন"},{"type":"paragraph","text":"তাপমাত্রা নিয়ন্ত্রিত রেফ্রিজারেটেড ভ্যানে ঘাট থেকে সরাসরি ঢাকার নির্ধারিত গুদাম বা ক্রেতার ঠিকানায় পরিবহন করা হয়। পুরো যাত্রায় তাপমাত্রা পর্যবেক্ষণ করা হয়, যাতে মাছের স্বাদ ও গঠন অক্ষুণ্ণ থাকে।"},{"type":"link","href":"/buy","label":"আজকের লাইভ ইলিশ স্টক দেখুন","description":"চাঁদপুর ঘাট থেকে সদ্য আহরিত ইলিশের বর্তমান পাইকারি লট ও মূল্য দেখুন।"},{"type":"heading","text":"কেন পাইকারি ক্রেতাদের জন্য এই মৌসুম গুরুত্বপূর্ণ"},{"type":"paragraph","text":"ভরা মৌসুমে সরবরাহ বেশি থাকায় দাম তুলনামূলক স্থিতিশীল থাকে, ফলে বাল্ক অর্ডারে সুপারশপ ও হোটেল চেইনগুলো ভালো মূল্যে দীর্ঘমেয়াদি সরবরাহ চুক্তি করতে পারে। যারা নিয়মিত বড় লট প্রয়োজন মনে করেন, তারা আগেভাগে চাহিদা জানিয়ে রাখলে সরবরাহ নিশ্চিত করা সহজ হয়।"},{"type":"link","href":"/invest","label":"ইলিশ সংগ্রহ প্রকল্পে অংশ নিন","description":"চাঁদপুরের ইলিশ সংগ্রহ ও সরবরাহ প্রকল্পে বিনিয়োগের সুযোগ সম্পর্কে জানুন।"},{"type":"quote","text":"ঘাট থেকে গুদাম পর্যন্ত তাপমাত্রার ধারাবাহিকতা বজায় রাখাই ইলিশের প্রকৃত স্বাদ সংরক্ষণের মূল চাবিকাঠি।"}]', 'ইলিশ', '/hero-fishermen-boat.png', 'চাঁদপুরের মেঘনা নদীতে জেলে নৌকা থেকে ইলিশ আহরণ',
  'Gangchill প্রকিউরমেন্ট টিম', '2026-08-20', '৬ মিনিট পড়া', 'ইলিশ মৌসুম ২০২৬: চাঁদপুর থেকে ঢাকার পাইকারি বাজার পর্যন্ত সরবরাহ চেইন | Gangchill', 'চাঁদপুরের বড়স্টেশন ঘাট থেকে সংগৃহীত ইলিশ কীভাবে কোল্ড-চেইনের মাধ্যমে ঢাকার পাইকারি ও কর্পোরেট ক্রেতাদের কাছে পৌঁছায়—Gangchill-এর সরবরাহ প্রক্রিয়ার বিস্তারিত বিবরণ।', '["ইলিশ মাছ","চাঁদপুর ইলিশ","পাইকারি ইলিশ","কোল্ড চেইন মাছ সরবরাহ"]', 1
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `blog_posts` (`slug`, `title`, `excerpt`, `content`, `category`, `featured_image`, `image_alt`, `author`, `published_at`, `reading_time`, `seo_title`, `seo_description`, `keywords`, `featured`) VALUES (
  'paikari-mach-kena-7-bishoy-jachai', 'পাইকারি মাছ কেনার আগে যে ৭টি বিষয় অবশ্যই যাচাই করবেন', 'বড় লটে মাছ কেনার সময় তাজাত্ব, গ্রেডিং, প্যাকেজিং থেকে শুরু করে সরবরাহকারীর স্বচ্ছতা পর্যন্ত—কর্পোরেট ও পাইকারি ক্রেতাদের জন্য একটি ব্যবহারিক চেকলিস্ট।', '[{"type":"paragraph","text":"বড় ভলিউমে মাছ কেনা মানেই বাড়তি ঝুঁকি ও বাড়তি দায়িত্ব। একবার লট গ্রহণ করার পর মান নিয়ে সমস্যা দেখা দিলে পুরো ব্যাচ নষ্ট হওয়ার আশঙ্কা থাকে। তাই পাইকারি বা কর্পোরেট ক্রেতাদের জন্য কেনার আগে কিছু বিষয় যাচাই করা জরুরি।"},{"type":"heading","text":"১. তাজাত্বের ভৌত সূচক"},{"type":"paragraph","text":"উজ্জ্বল, স্বচ্ছ চোখ; লালচে গিল; টানটান ও চকচকে আঁশ; এবং চাপ দিলে দ্রুত পূর্বাবস্থায় ফিরে আসা মাংস—এই চারটি সূচক তাজাত্ব নির্ধারণের সবচেয়ে নির্ভরযোগ্য উপায়।"},{"type":"heading","text":"২. উৎস ও আহরণের সময়"},{"type":"paragraph","text":"মাছ কোন ঘাট বা ঘের থেকে, কখন আহরিত হয়েছে তা জানা থাকলে সরবরাহ চেইনের দৈর্ঘ্য বোঝা যায়। আহরণ থেকে ডেলিভারি যত কম সময়ে সম্পন্ন হয়, তাজাত্ব তত বেশি থাকে।"},{"type":"heading","text":"৩. গ্রেডিং মান ও আকার সামঞ্জস্য"},{"type":"paragraph","text":"একই লটে আকার ও ওজনের ধারাবাহিকতা থাকা উচিত। অসামঞ্জস্যপূর্ণ গ্রেডিং প্রায়ই নিম্নমানের সরবরাহকারীর লক্ষণ।"},{"type":"heading","text":"৪. আইসিং ও প্যাকেজিং মান"},{"type":"paragraph","text":"ফুড-গ্রেড বরফ এবং ইনসুলেটেড থার্মোকল বা ক্রেট ব্যবহার হচ্ছে কিনা যাচাই করুন। অপর্যাপ্ত আইসিং পরিবহনের সময় দ্রুত গুণমান নষ্ট করে দেয়।"},{"type":"heading","text":"৫. কোল্ড-চেইন ধারাবাহিকতা"},{"type":"paragraph","text":"ঘাট থেকে গুদাম পর্যন্ত তাপমাত্রা নিয়ন্ত্রিত পরিবহন ব্যবহৃত হচ্ছে কিনা, এবং কোনো পর্যায়ে তাপমাত্রার ব্যত্যয় ঘটছে কিনা—তা সরবরাহকারীর কাছে সরাসরি জিজ্ঞাসা করুন।"},{"type":"heading","text":"৬. ন্যূনতম অর্ডার ও মূল্য স্বচ্ছতা"},{"type":"paragraph","text":"ন্যূনতম অর্ডারের পরিমাণ, দামের ধরন (নির্দিষ্ট, আলোচনাসাপেক্ষ বা বাজারদর-নির্ভর) এবং অতিরিক্ত চার্জ থাকলে তা আগেভাগেই স্পষ্ট থাকা উচিত।"},{"type":"heading","text":"৭. প্রামাণ্য ট্র্যাকিং ও যোগাযোগ"},{"type":"paragraph","text":"ডেলিভারি স্ট্যাটাস ট্র্যাক করার সুযোগ এবং সমস্যা হলে দ্রুত সমাধানের জন্য সরাসরি যোগাযোগের মাধ্যম থাকা উচিত।"},{"type":"link","href":"/buy","label":"আজকের যাচাইকৃত পাইকারি স্টক দেখুন","description":"Gangchill-এর লাইভ স্টক বোর্ডে প্রতিটি লটের গ্রেড, উৎস ও প্যাকেজিং তথ্য উল্লেখ থাকে।"},{"type":"link","href":"/contact","label":"নিয়মিত বাল্ক সরবরাহের জন্য যোগাযোগ করুন","description":"সুপারশপ, হোটেল বা রেস্তোরাঁর জন্য নির্দিষ্ট চাহিদা থাকলে আমাদের সেলস টিমের সাথে কথা বলুন।"}]', 'ক্রয় গাইড', '/hero-boats.jpg', 'উপকূলীয় ঘাটে নোঙর করা মাছ ধরার ট্রলার',
  'Gangchill কন্টেন্ট টিম', '2026-08-05', '৫ মিনিট পড়া', 'পাইকারি মাছ কেনার আগে ৭টি জরুরি বিষয় যাচাই করুন | Gangchill', 'সুপারশপ, হোটেল ও রেস্তোরাঁর জন্য পাইকারি মাছ কেনার সময় তাজাত্ব, গ্রেড, প্যাকেজিং ও কোল্ড-চেইন যাচাইয়ের ব্যবহারিক নির্দেশিকা।', '["পাইকারি মাছ ক্রয়","মাছের গ্রেডিং","কর্পোরেট মাছ সরবরাহ","তাজা মাছ চেনার উপায়"]', 0
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `blog_posts` (`slug`, `title`, `excerpt`, `content`, `category`, `featured_image`, `image_alt`, `author`, `published_at`, `reading_time`, `seo_title`, `seo_description`, `keywords`, `featured`) VALUES (
  'cold-chain-logistics-ghat-theke-gudam', 'কোল্ড-চেইন লজিস্টিক্স: ঘাট থেকে গুদাম পর্যন্ত মাছের সতেজতা যেভাবে বজায় থাকে', 'তাপমাত্রা নিয়ন্ত্রণ, আইসিং কৌশল ও পরিবহন ব্যবস্থাপনা—মাছ আহরণের পর থেকে ক্রেতার কাছে পৌঁছানো পর্যন্ত কোল্ড-চেইনের প্রতিটি স্তর কীভাবে কাজ করে তা জানুন।', '[{"type":"paragraph","text":"সামুদ্রিক বা নদীর মাছ আহরণের মুহূর্ত থেকেই গুণমান হ্রাস শুরু হয়ে যায়। সঠিক কোল্ড-চেইন ব্যবস্থাপনা ছাড়া দীর্ঘ দূরত্বে পরিবহন করে তাজা মাছ সরবরাহ করা কার্যত অসম্ভব।"},{"type":"heading","text":"কোল্ড-চেইনের তিনটি প্রধান স্তর"},{"type":"list","items":["প্রাথমিক আইসিং: ঘাট বা ঘের থেকে খালাসের সাথে সাথেই ফুড-গ্রেড বরফ প্রয়োগ","পরিবহন পর্যায়: তাপমাত্রা নিয়ন্ত্রিত রেফ্রিজারেটেড ভ্যান বা ইনসুলেটেড কন্টেইনার","গুদাম ও ডেলিভারি: নির্ধারিত তাপমাত্রায় সংরক্ষণ ও দ্রুত হস্তান্তর"]},{"type":"heading","text":"কেন তাপমাত্রার ধারাবাহিকতা গুরুত্বপূর্ণ"},{"type":"paragraph","text":"তাপমাত্রায় সামান্য ওঠানামাও ব্যাকটেরিয়ার বৃদ্ধি ত্বরান্বিত করে এবং মাছের গঠন নষ্ট করে দেয়। তাই পুরো যাত্রাপথে ধারাবাহিক তাপমাত্রা বজায় রাখাই মূল লক্ষ্য।"},{"type":"heading","text":"ফরমালিন ও রাসায়নিকমুক্ত সংরক্ষণ"},{"type":"paragraph","text":"সঠিক আইসিং ও দ্রুত পরিবহন থাকলে কোনো প্রকার কৃত্রিম সংরক্ষক ব্যবহারের প্রয়োজন হয় না। এটি শুধু নিরাপদ খাদ্য নিশ্চিত করে না, বরং মাছের প্রাকৃতিক স্বাদও অক্ষুণ্ণ রাখে।"},{"type":"link","href":"/sell","label":"আপনার মাছ কোল্ড-চেইনে বিক্রি করুন","description":"জেলে ও খামারিরা সরাসরি Gangchill-এর কোল্ড-চেইন নেটওয়ার্কের মাধ্যমে বাজারে মাছ সরবরাহ করতে পারেন।"},{"type":"heading","text":"পাইকারি ক্রেতাদের জন্য গুরুত্ব"},{"type":"paragraph","text":"যেসব প্রতিষ্ঠান নিয়মিত বড় ভলিউমে মাছ কেনেন, তাদের জন্য সরবরাহকারীর কোল্ড-চেইন ক্ষমতা যাচাই করা অত্যন্ত গুরুত্বপূর্ণ—কারণ এটিই নির্ধারণ করে পণ্যের প্রকৃত মান।"}]', 'লজিস্টিক্স', '/hero-fishing-net.png', 'মাছ ধরার জাল ও উপকূলীয় পরিবহন প্রস্তুতি',
  'Gangchill অপারেশনস টিম', '2026-07-22', '৭ মিনিট পড়া', 'কোল্ড-চেইন লজিস্টিক্স: মাছের সতেজতা বজায় রাখার প্রক্রিয়া | Gangchill', 'ঘাট থেকে গুদাম পর্যন্ত মাছের কোল্ড-চেইন কীভাবে পরিচালিত হয়—আইসিং, তাপমাত্রা নিয়ন্ত্রণ ও পরিবহন ব্যবস্থাপনার বিস্তারিত ব্যাখ্যা।', '["কোল্ড চেইন লজিস্টিক্স","মাছ পরিবহন","ফুড সাপ্লাই চেইন","তাজা মাছ সংরক্ষণ"]', 0
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `blog_posts` (`slug`, `title`, `excerpt`, `content`, `category`, `featured_image`, `image_alt`, `author`, `published_at`, `reading_time`, `seo_title`, `seo_description`, `keywords`, `featured`) VALUES (
  'chalanbeel-pabda-mishtipanir-sera-paikari', 'চলনবিলের পাবদা: মিঠাপানির সেরা পাইকারি সংগ্রহ কীভাবে হয়', 'উত্তরবঙ্গের চলনবিল অঞ্চল থেকে পাবদা মাছ সংগ্রহ, গ্রেডিং ও ঢাকার পাইকারি বাজারে সরবরাহ প্রক্রিয়ার বিস্তারিত বিবরণ।', '[{"type":"paragraph","text":"নাটোর, পাবনা ও সিরাজগঞ্জ জুড়ে বিস্তৃত চলনবিল অঞ্চল মিঠাপানির মাছ চাষের জন্য দেশের অন্যতম গুরুত্বপূর্ণ এলাকা। এখানকার ঘের থেকে সংগৃহীত পাবদা তার স্বাদ ও গঠনের জন্য পাইকারি বাজারে বিশেষভাবে সমাদৃত।"},{"type":"heading","text":"ঘের থেকে আহরণ"},{"type":"paragraph","text":"স্থানীয় খামারিরা নির্দিষ্ট বয়স ও আকারে পৌঁছালে পাবদা আহরণ করেন। আহরণের সময় জাল ব্যবহারে সতর্কতা বজায় রাখা হয়, যাতে মাছের শরীরে আঘাত না লাগে।"},{"type":"heading","text":"গ্রেডিং ও বাছাই"},{"type":"paragraph","text":"আকার ও ওজন অনুযায়ী পাবদা বাছাই করে পৃথক ক্রেটে রাখা হয়। অভিন্ন আকারের লট রেস্তোরাঁ ও সুপারশপের জন্য বেশি উপযোগী, কারণ এতে রান্না ও প্রদর্শনে সামঞ্জস্য বজায় থাকে।"},{"type":"heading","text":"পরিবহন ও ঢাকার বাজারে সরবরাহ"},{"type":"paragraph","text":"বাছাইকৃত পাবদা ইনসুলেটেড ক্রেটে বরফসহ প্যাক করে সড়কপথে ঢাকার পাইকারি ও কর্পোরেট ক্রেতাদের কাছে পাঠানো হয়। সাধারণত ঘের থেকে খালাসের একই দিনে ডেলিভারি সম্পন্ন হয়।"},{"type":"link","href":"/buy","label":"মিঠাপানির মাছের বর্তমান স্টক দেখুন","description":"পাবদাসহ বিভিন্ন মিঠাপানির মাছের লাইভ ও আসন্ন লট Gangchill-এর স্টক বোর্ডে দেখুন।"},{"type":"quote","text":"অভিন্ন গ্রেডিং ও সময়মতো পরিবহনই মিঠাপানির মাছের বাণিজ্যিক মূল্য নির্ধারণ করে।"}]', 'মিঠাপানির মাছ', '/chalanbeel-pabda.jpg', 'চলনবিল অঞ্চলের ঘেরে পাবদা মাছ সংগ্রহ',
  'Gangchill প্রকিউরমেন্ট টিম', '2026-07-10', '৫ মিনিট পড়া', 'চলনবিলের পাবদা মাছ: মিঠাপানির পাইকারি সংগ্রহ প্রক্রিয়া | Gangchill', 'উত্তরবঙ্গের চলনবিল থেকে পাবদা মাছ সংগ্রহ, গ্রেডিং ও কোল্ড-চেইনে ঢাকার পাইকারি বাজারে সরবরাহের সম্পূর্ণ প্রক্রিয়া জানুন।', '["পাবদা মাছ","চলনবিল","মিঠাপানির মাছ","পাইকারি মাছ সংগ্রহ"]', 0
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);
INSERT INTO `blog_posts` (`slug`, `title`, `excerpt`, `content`, `category`, `featured_image`, `image_alt`, `author`, `published_at`, `reading_time`, `seo_title`, `seo_description`, `keywords`, `featured`) VALUES (
  'nazirartek-shutki-coxsbazar-oitihyobahi-banijjo', 'নাজিরারটেক শুঁটকি: কক্সবাজারের ঐতিহ্যবাহী শুকনো মাছের বাণিজ্য', 'কক্সবাজারের নাজিরারটেক শুঁটকি পল্লীতে কীভাবে সামুদ্রিক মাছ শুকিয়ে প্রক্রিয়াজাত করা হয় এবং তা কীভাবে পাইকারি বাজারে সরবরাহ হয়—একটি বিস্তারিত পরিচিতি।', '[{"type":"paragraph","text":"কক্সবাজারের নাজিরারটেক দেশের সবচেয়ে বড় শুঁটকি প্রক্রিয়াজাতকরণ কেন্দ্রগুলোর একটি। এখানে সামুদ্রিক মাছ সূর্যের আলোয় প্রাকৃতিকভাবে শুকিয়ে দীর্ঘমেয়াদি সংরক্ষণের উপযোগী করে তোলা হয়।"},{"type":"heading","text":"প্রক্রিয়াজাতকরণ পদ্ধতি"},{"type":"paragraph","text":"তাজা মাছ প্রথমে পরিষ্কার করে লবণ মাখিয়ে খোলা মাচায় শুকাতে দেওয়া হয়। আবহাওয়া অনুকূল থাকলে কয়েক দিনের মধ্যেই মাছ যথাযথভাবে শুকিয়ে যায়। মান নিয়ন্ত্রণের জন্য নিয়মিত পর্যবেক্ষণ প্রয়োজন হয়, যাতে অতিরিক্ত আর্দ্রতা বা ধুলাবালি মিশ্রিত না হয়।"},{"type":"heading","text":"গুণমান যাচাইয়ের মানদণ্ড"},{"type":"list","items":["রঙ ও গন্ধ স্বাভাবিক ও অক্ষত থাকা","পর্যাপ্ত শুষ্কতা যাতে ছত্রাক জন্মাতে না পারে","ধুলাবালি বা বহিরাগত পদার্থমুক্ত প্যাকেজিং"]},{"type":"heading","text":"পাইকারি বাজারে সরবরাহ"},{"type":"paragraph","text":"প্রক্রিয়াজাত শুঁটকি বায়ুরোধী বস্তা বা কনটেইনারে প্যাক করে দেশের বিভিন্ন পাইকারি বাজার ও সুপারশপে সরবরাহ করা হয়। সঠিক প্যাকেজিং শুঁটকির স্বাদ ও গুণমান দীর্ঘদিন বজায় রাখতে সাহায্য করে।"},{"type":"link","href":"/buy","label":"শুঁটকির পাইকারি লট দেখুন","description":"নাজিরারটেকের প্রক্রিয়াজাত শুঁটকির বর্তমান সংগ্রহ Gangchill-এর স্টক বোর্ডে দেখুন।"},{"type":"link","href":"/sell","label":"শুঁটকি প্রক্রিয়াজাতকারী হিসেবে যুক্ত হোন","description":"কক্সবাজার অঞ্চলের শুঁটকি ব্যবসায়ীরা সরাসরি Gangchill-এর মাধ্যমে পাইকারি বাজারে সরবরাহ করতে পারেন।"}]', 'শুঁটকি', '/nazirartek-shutki.jpg', 'কক্সবাজারের নাজিরারটেক শুঁটকি পল্লীতে মাছ শুকানোর দৃশ্য',
  'Gangchill কন্টেন্ট টিম', '2026-06-28', '৬ মিনিট পড়া', 'নাজিরারটেক শুঁটকি: কক্সবাজারের ঐতিহ্যবাহী শুকনো মাছের বাণিজ্য | Gangchill', 'কক্সবাজারের নাজিরারটেক শুঁটকি পল্লীর প্রক্রিয়াজাতকরণ পদ্ধতি এবং পাইকারি বাজারে সরবরাহের প্রক্রিয়া সম্পর্কে জানুন।', '["শুঁটকি মাছ","নাজিরারটেক","কক্সবাজার শুঁটকি","পাইকারি শুঁটকি ব্যবসা"]', 0
) ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);

-- 5. Verified B2B Customers
INSERT INTO `customers` (`id`, `company_name`, `business_type`, `contact_person`, `phone`, `email`, `delivery_location`, `tier`, `total_orders_count`, `total_volume_kg`, `total_order_value`, `last_order_date`, `preferred_fish`) VALUES (
  'CUST-001', 'ইউনিমার্ট সুপারশপ (গুলশান ২ ব্রাঞ্চ)', 'সুপারশপ চেইন', 'তানভীর আহমেদ', '01711-223344', 'procurement@unimart.com.bd', 'গুলশান ২, ঢাকা', 'VIP', 8, 2850.00, 4617000.00, '2026-09-14', '["পদ্মার রূপালী ইলিশ","চলনবিলের পাবদা","গলদা চিংড়ি"]'
) ON DUPLICATE KEY UPDATE `company_name` = VALUES(`company_name`);

-- 6. Coastal Suppliers & Cooperatives
INSERT INTO `suppliers` (`id`, `farmer_name`, `type`, `phone`, `district`, `location`, `verification_badge`, `total_lots_count`, `total_volume_kg`, `quality_rating`, `primary_species`, `joined_date`) VALUES (
  'SUP-001', 'মো: মোশাররফ হোসেন (জেলে সমবায়)', 'জেলে সমবায়', '01715-998877', 'চাঁদপুর', 'বড়স্টেশন মোহনা ঘাট', 'verified', 14, 8500.00, 4.9, '["পদ্মার রূপালী ইলিশ","মেঘনার পাঙ্গাশ","তপসে"]', '2025-11-10'
) ON DUPLICATE KEY UPDATE `farmer_name` = VALUES(`farmer_name`);

-- 7. Initial Buyer Orders
INSERT INTO `buyer_orders` (`id`, `company_name`, `contact_person`, `phone`, `email`, `product_name`, `quantity`, `unit`, `required_date`, `delivery_location`, `specification`, `notes`, `status`, `order_status`, `quoted_price_per_unit`, `total_estimated_value`, `assigned_staff`, `status_history`, `internal_notes`) VALUES (
  'REQ-1726001001', 'ইউনিমার্ট সুপারশপ (গুলশান ২ ব্রাঞ্চ)', 'তানভীর আহমেদ', '01711-223344', 'procurement@unimart.com.bd', 'চাঁদপুরের পদ্মার রূপালী ইলিশ', 350.00, 'কেজি (KG)', '2026-09-20', 'গুলশান ২, ঢাকা', '১ কেজি+ সাইজ গ্রেড, তাজা বরফ প্যাক', 'সকাল ৮টার মধ্যে আনলোড নিশ্চিত করতে হবে', 'pending', 'under_review', 1620.00, 567000.00, 'MD Admin', '[{"status":"pending","timestamp":"2026-09-14T08:30:00Z","updatedBy":"সিস্টেম","note":"চাহিদাপত্র জমা"}]', 'কোল্ড চেইন পরিবহন দল প্রস্তুত'
) ON DUPLICATE KEY UPDATE `company_name` = VALUES(`company_name`);

-- 8. Coastal Harvest Seller Lots
INSERT INTO `seller_lots` (`id`, `farmer_name`, `phone`, `district`, `product_name`, `stock_type`, `quantity`, `unit`, `location`, `availability_date`, `expected_price`, `description`, `images`, `status`, `verification_status`, `field_inspector_name`, `inspection_notes`, `approved_wholesale_price`) VALUES (
  'LOT-1726002001', 'মো: মোশাররফ হোসেন', '01715-998877', 'চাঁদপুর', 'পদ্মার রূপালী ইলিশ (তাজা লট)', 'current', 850.00, 'কেজি (KG)', 'বড়স্টেশন মোহনা ঘাট, চাঁদপুর', 'আজ ভোরের আহরণ', 1550.00, 'মেঘনা-পদ্মার সঙ্গমস্থল থেকে আহরিত খাঁটি চকচকে ইলিশ। সরাসরি বরফ প্যাকেজে রেডি।', '["https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80"]', 'submitted', 'verified', 'MD Admin', 'ঘাট পয়েন্টে কোয়ালিটি অডিট সফল।', 1550.00
) ON DUPLICATE KEY UPDATE `farmer_name` = VALUES(`farmer_name`);
